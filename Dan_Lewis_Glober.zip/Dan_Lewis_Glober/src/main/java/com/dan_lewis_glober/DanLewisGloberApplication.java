package com.dan_lewis_glober;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DanLewisGloberApplication {

    public static void main(String[] args) {
        SpringApplication.run(DanLewisGloberApplication.class, args);
    }

}
