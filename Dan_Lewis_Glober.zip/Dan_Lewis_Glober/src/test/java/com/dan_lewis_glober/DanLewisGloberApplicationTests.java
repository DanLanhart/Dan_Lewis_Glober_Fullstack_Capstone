package com.dan_lewis_glober;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DanLewisGloberApplicationTests {

    @Test
    void contextLoads() {
    }

}
